package com.example.a1cr20cs155_calculator

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import javax.xml.xpath.XPathExpression
import net.objecthunter.exp4j.ExpressionBuilder
import java.lang.Exception

class MainActivity : AppCompatActivity() {

    lateinit var expression: TextView
    lateinit var result: TextView
    lateinit var clear: TextView
    lateinit var one: TextView
    lateinit var two: TextView
    lateinit var three: TextView
    lateinit var four: TextView
    lateinit var five: TextView
    lateinit var six: TextView
    lateinit var seven: TextView
    lateinit var eight: TextView
    lateinit var nine: TextView
    lateinit var zero: TextView
    lateinit var dot: TextView
    lateinit var equal: TextView
    lateinit var plus: TextView
    lateinit var minus: TextView
    lateinit var multiply: TextView
    lateinit var division: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        expression = findViewById(R.id.expression)
        result = findViewById(R.id.result)
        clear = findViewById(R.id.clear)
        one = findViewById(R.id.one)
        two = findViewById(R.id.two)
        three = findViewById(R.id.three)
        four = findViewById(R.id.four)
        five = findViewById(R.id.five)
        six = findViewById(R.id.six)
        seven = findViewById(R.id.seven)
        eight = findViewById(R.id.eight)
        nine = findViewById(R.id.nine)
        zero = findViewById(R.id.zero)
        dot = findViewById(R.id.dot)
        equal = findViewById(R.id.equal)
        plus = findViewById(R.id.plus)
        minus = findViewById(R.id.minus)
        multiply = findViewById(R.id.multiply)
        division = findViewById(R.id.division)


        clear.setOnClickListener {
            result.text = ""
            expression.text = ""
        }

        one.setOnClickListener {
            pressButton("1")
        }

        two.setOnClickListener {
            pressButton("2")

        }

        three.setOnClickListener {
            pressButton("3")

        }

        four.setOnClickListener {
            pressButton("4")

        }

        five.setOnClickListener {
            pressButton("5")

        }

        six.setOnClickListener {
            pressButton("6")

        }

        seven.setOnClickListener {
            pressButton("7")

        }

        eight.setOnClickListener {
            pressButton("8")

        }

        nine.setOnClickListener {
            pressButton("9")

        }

        zero.setOnClickListener {
            pressButton("0")

        }

        dot.setOnClickListener {
            pressButton(".")

        }


        plus.setOnClickListener {
            pressButton("+")

        }

        minus.setOnClickListener {
            pressButton("-")

        }

        multiply.setOnClickListener {
            pressButton("*")

        }

        division.setOnClickListener {
            pressButton("/")

        }

        equal.setOnClickListener {
            try{
                val text = expression.text.toString()
                val expression = ExpressionBuilder(text).build()
                val expResult = expression.evaluate().toDouble()
                result.text = expResult.toString()
            }
            catch (e:Exception){
                result.text = "Error"
            }
        }

    }

    fun pressButton(str: String){
        result.text = ""
        expression.append(str)
    }
}