package com.example.loginsignup_155

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    lateinit var loginusername : EditText
    lateinit var loginpassword : EditText
    lateinit var loginbutton : Button
    var count : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        loginusername = findViewById(R.id.loginusername)
        loginpassword = findViewById(R.id.loginpassword)
        loginbutton = findViewById(R.id.loginbutton)

        val bundle : Bundle? = intent.extras
        val user : String? = bundle?.getString("username")
        val pass : String? = bundle?.getString("password")

        loginbutton.setOnClickListener {
            validatelogindetails(user,pass)
        }
    }

    private fun validatelogindetails(user: String?, pass: String?) {
        val uname : String = loginusername.text.toString()
        val pwd : String = loginpassword.text.toString()

        if(uname == user && pwd == pass)
        {
            intent = Intent(this, successActivity::class.java)
            startActivity(intent)
        }
        else
        {
            count++
            if(count>3)
            {
                loginbutton.isEnabled = false
                Toast.makeText(this, "Failed Login Attempts", Toast.LENGTH_SHORT).show()
            }
            else
            {
                Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}