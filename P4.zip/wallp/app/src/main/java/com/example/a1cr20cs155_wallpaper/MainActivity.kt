package com.example.a1cr20cs155_wallpaper

import android.app.WallpaperManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.Button

class MainActivity : AppCompatActivity() {
    var wallpaperlist :  Array<Int> = arrayOf(R.drawable.img1, R.drawable.img2, R.drawable.img3, R.drawable.img4)
    private lateinit var changewallpaper : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        changewallpaper = findViewById(R.id.startbutton)
        changewallpaper.setOnClickListener{setwallpaper()}
    }

    fun setwallpaper(){
        Handler().postDelayed(
            {
                for(i in wallpaperlist)
                {
                    val manager = WallpaperManager.getInstance(baseContext)
                    manager.setResource(i)
                    Thread.sleep(3000)
                }
            }
        ,5000)
    }
}