package com.example.counter155

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    lateinit var countervalue: TextView
    lateinit var startbutton: Button
    lateinit var stopbutton: Button
    lateinit var resetbutton: Button

    var count : Int = 0
    var timer = MyCounter(10000, 1000)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        countervalue = findViewById(R.id.counter_value)
        startbutton = findViewById(R.id.start_button)
        stopbutton = findViewById(R.id.stop_button)
        resetbutton = findViewById(R.id.reset_button)

        startbutton.setOnClickListener {
            timer.start()
            startbutton.isEnabled = false
        }

        stopbutton.setOnClickListener {
            timer.cancel()
            startbutton.isEnabled = true
        }

        resetbutton.setOnClickListener {
            count = 0
            countervalue.text = (count).toString()
            startbutton.isEnabled = true
        }
    }

    inner class MyCounter(x: Long, y: Long) : CountDownTimer(x, y)
    {
        override fun onTick(millisUntilFinished: Long) {
            count++
            countervalue.text = (count).toString()
        }

        override fun onFinish() {
            count = 0
            countervalue.text = "Finished"
        }

    }
}