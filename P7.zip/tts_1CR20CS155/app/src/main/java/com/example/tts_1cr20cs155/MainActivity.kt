package com.example.tts_1cr20cs155

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Button
import android.widget.EditText
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    lateinit var textinfo : EditText
    lateinit var speakbutton : Button
    lateinit var texttospeech : TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textinfo = findViewById(R.id.textinfo)
        speakbutton = findViewById(R.id.speakbutton)
        texttospeech = TextToSpeech(this, this)

        speakbutton.setOnClickListener {
            convertToSpeech()
        }


    }

    private fun convertToSpeech() {
        var text = textinfo.text.toString()
        texttospeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "")
    }

    override fun onInit(status: Int) {
        if(status == TextToSpeech.SUCCESS)
        {
            texttospeech.setLanguage(Locale.ENGLISH)
        }
        else
        {
            Log.e("tts", "TTS package not loaded")
        }
    }
}