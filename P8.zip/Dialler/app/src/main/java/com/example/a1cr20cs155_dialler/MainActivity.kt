package com.example.a1cr20cs155_dialler

import android.content.Intent
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var contact : TextView
    lateinit var clear : TextView
    lateinit var one : TextView
    lateinit var two : TextView
    lateinit var three : TextView
    lateinit var four : TextView
    lateinit var five : TextView
    lateinit var six : TextView
    lateinit var seven : TextView
    lateinit var eight : TextView
    lateinit var nine : TextView
    lateinit var zero : TextView
    lateinit var star : TextView
    lateinit var pound : TextView
    lateinit var call : Button
    lateinit var save : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        contact = findViewById(R.id.contact)
        clear = findViewById(R.id.clear)
        one = findViewById(R.id.one)
        two = findViewById(R.id.two)
        three = findViewById(R.id.three)
        four = findViewById(R.id.four)
        five = findViewById(R.id.five)
        six = findViewById(R.id.six)
        seven = findViewById(R.id.seven)
        eight = findViewById(R.id.eight)
        nine = findViewById(R.id.nine)
        zero = findViewById(R.id.zero)
        star = findViewById(R.id.star)
        pound = findViewById(R.id.pound)
        call = findViewById(R.id.call)
        save = findViewById(R.id.save)

        clear.setOnClickListener {
            contact.text = ""
        }

        one.setOnClickListener {
            press("1")
        }

        two.setOnClickListener {
            press("2")

        }

        three.setOnClickListener {
            press("3")

        }

        four.setOnClickListener {
            press("4")

        }
        five.setOnClickListener {
            press("5")

        }
        six.setOnClickListener {
            press("6")

        }
        seven.setOnClickListener {
            press("7")

        }
        eight.setOnClickListener {
            press("8")

        }
        nine.setOnClickListener {
            press("9")

        }
        zero.setOnClickListener {
            press("0")

        }
        star.setOnClickListener {
            press("*")

        }
        pound.setOnClickListener {
            press("#")

        }
        call.setOnClickListener {
            var intent = Intent(Intent.ACTION_DIAL)
            var info = Uri.parse("tel:" + contact.text)
            intent.data = info
            startActivity(intent)
        }
        save.setOnClickListener {
            var intent = Intent(ContactsContract.Intents.Insert.ACTION)
            intent.type = ContactsContract.RawContacts.CONTENT_TYPE
            intent.putExtra(ContactsContract.Intents.Insert.PHONE, contact.text)
            startActivity(intent)
        }


    }

    private fun press(s: String) {
        contact.append(s)
    }
}